# Contact block

---

**This module has reached end-of-life and is no longer maintained.**

It has been remade for PrestaShop 1.7: https://github.com/PrestaShop/ps_contactinfo

---

## About

Allows you to add additional information about your store's customer service.
